// TODO: add transform to simplify the graphql response
