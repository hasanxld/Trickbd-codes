export const cookiesKeys = {
  THEME: "MY_THEME",
  LOCALE: "MY_LOCALE",
} as const;
